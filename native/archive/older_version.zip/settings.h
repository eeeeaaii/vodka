#ifndef SETTINGSDOTH
#define SETTINGSDOTH

//#define RCM_MULTITHREADED



#endif