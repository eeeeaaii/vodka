#include "Carin.h"
#include "IDEEventHandler.h"

#include "pExp.h"
#include "Event.h"
#include "Expression.h"
#include "StorageManager.h"
#include "Pair.h"
#include "Machine.h"


void IDECreateNextSiblingHandler::notify(Event *e)
{
	sPtr parent = exp->getParent();
	if (!sPtr) return;
	Pair* parentP = (Pair*)parent;
	sPtr newp = GSM.newPair(GSM.newExpression(), parentP->getCdr());
	parentP->setCdr(newp);
	((Pair*)newp)->setDirection(parentP->getDirection());
	parentP->setDirtyness(parentP->getDirtyness() | parentP->getDirection());
	exp = ((Pair*)newp)->getCar();
}

// finish
void IDECreatePreviousSiblingHandler::notify(Event *e)
{
	sPtr parent = exp->getParent();
	if (!sPtr) return;
	sPtr grandparent = parent->getParent();
	Pair* grandparentP = (Pair*)grandparent;
	sPtr n = GSM.newPair(GSM.newExpression(), exp);
	((Pair*)n)->setDirection(((Pair*)exp)->getDirection());
	exp->setDirtyness(exp->getDirtyness() | ((Pair*)n)->getDirection());
	if (grandparentP->getCdr() == parent) {
		grandparentP->setCdr(n);
	} else if (grandparentP->getCar() == parent) {
		grandparentP->setCar(n);
	}

	//swapSelected(((Pair*)n)->getCar(), ((Pair*)exp)->getCar());
	return n;
}

// to do
void IDEMoveNextSiblingHandler::notify(Event *e)
{
	swapSelected(((Pair*)exp)->getCar(), ((Pair*)((Pair*)exp)->getCdr())->getCar());
	return exp;
}

// to do
void IDEMovePreviousSiblingHandler::notify(Event *e)
{
	// move previous sibling
	swapSelected(((Pair*)((Pair*)exp)->getCdr())->getCar(), ((Pair*)exp)->getCar());
	return exp;
}

// to do
void IDEDisbandHandler::notify(Event *e)
{
	// disband
	sPtr sel;
	sPtr restoflist;
	sel = ((Pair*)exp)->getCar();
	restoflist = ((Pair*)exp)->getCdr();
//	swapSelected(sel, exp);
	if (!((Pair*)sel)->getCdr()->isType(XT_NULL)) {
		((Pair*)exp)->setCdr(((Pair*)sel)->getCdr());
		((Pair*)sel->lastSibling())->setCdr(restoflist);
	}
	((Pair*)exp)->setCar(((Pair*)sel)->getCar());
	swapSelected(((Pair*)exp)->getCar(), sel);
	for (sPtr p = ((Pair*)exp)->getCdr() ; !p->isType(XT_NULL) ; p = ((Pair*)p)->getCdr()) {
		((Pair*)p)->setDirection(((Pair*)exp)->getDirection());
		// flailing in the dark...
		((Pair*)p)->setDirtyness(HDIR | VDIR | ZDIR);
	}
	((Pair*)exp)->getCar()->setDirtyness(exp->getDirtyness() | HDIR | VDIR | ZDIR);
	return exp;
}

// to do
void IDEMoveOutHandler::notify(Event *e)
{
	sPtr c = findSelectedChild(exp);
	swapSelected(exp, c);
	((Pair*)exp)->setCachedChild(c);
	return exp;
}

// to do
void IDEEnlistHandler::notify(Event *e)
{
	// enlist
	sPtr n;
	n = GSM.newPair(exp, GSM.newNull());
	n->setDirtyness(n->getDirtyness() | HDIR | VDIR | ZDIR);
	//TRACE("%d", n->getDirtyness());
	return n;
}

// to do
void IDEMoveInHandler::notify(Event *e)
{
	sPtr cc = ((Pair*)exp)->getCachedChild();
	if (!!cc) {
		swapSelected(exp, cc);
	} else {
		swapSelected(((Pair*)exp)->getCar(), exp);
	}
	return exp;
}

// to do
void IDEEvalHandler::notify(Event *e)
{
	sPtr n;
	exp->setSelected(0);
	Machine m;
	m.setup(exp);
	m.process();
	n = m.result();
	n->setSelected(1);
	return n;
}

// to do
void IDEPivotHandler::notify(Event *e)
{
	for (sPtr p = exp ; !p->isType(XT_NULL) ; p = ((Pair*)p)->getCdr()) {
		Direction current_dir, new_dir;
		current_dir = ((Pair*)p)->getDirection();
		switch(current_dir) {
		case HDIR:
			new_dir = VDIR;
			break;
		case VDIR:
			new_dir = ZDIR;
			break;
		case ZDIR:
			new_dir = HDIR;
			break;
		}
		((Pair*)p)->setDirection(new_dir);
		p->setDirtyness(p->getDirtyness() | HDIR | VDIR | ZDIR);
	}
	return exp;
}

// to do
void IDEDeleteNodeHandler::notify(Event *e)
{
	if (exp->isPair()
		&& ((Pair*)exp)->getCar()->getSelected()) {
		if (((Pair*)exp)->getCdr()->isType(XT_NULL)) {
			((Pair*)exp)->getCdr()->setSelected(true);
		} else {
			((Pair*)((Pair*)exp)->getCdr())->getCar()->setSelected(true);
		}
		exp->setDirtyness(exp->getDirtyness() | ((Pair*)exp)->getDirection());
		return ((Pair*)exp)->getCdr();
	} else if (exp->isPair() 
		&& !((Pair*)exp)->getCdr()->isType(XT_NULL) 
		&& ((Pair*)((Pair*)exp)->getCdr())->getCar()->getSelected()) {
		((Pair*)exp)->getCar()->setSelected(true);
		((Pair*)exp)->setCdr(((Pair*)((Pair*)exp)->getCdr())->getCdr());
		exp->setDirtyness(exp->getDirtyness() | ((Pair*)exp)->getDirection());
		return exp;
	}
}

// to do
void IDEKeyTypedHandler::notify(Event *e)
{
	char buf[256];
	char *mt;
	mt = ((Pair*)exp)->getCar()->getMytext();
	assert(strlen(mt) + 2 < 256);
	if (!((Pair*)exp)->getCar()->isType(XT_UNKNOWN) && ((Pair*)exp)->getCar()->isType(XT_NULL)) {
		sprintf(buf, "%c", e->keyvalue);
	} else {
		sprintf(buf, "%s%c", mt, e->keyvalue);
	}
	((Pair*)exp)->setCar(GSM.newExpression(buf));
	((Pair*)exp)->getCar()->setSelected(true);
	exp->setDirtyness(exp->getDirtyness() | HDIR);
	return exp;
}

// to do
void IDERuboutHandler::notify(Event *e)
{
	char buf[256];
	char *mt;
	mt = ((Pair*)exp)->getCar()->getMytext();
	assert(strlen(mt) + 2 < 256);
	sprintf(buf, "%s", mt, e->keyvalue);
	if (buf[0] != '\0') buf[strlen(buf) - 1] = '\0';
	((Pair*)exp)->setCar(GSM.newExpression(buf));
	((Pair*)exp)->getCar()->setSelected(true);
	exp->setDirtyness(exp->getDirtyness() | HDIR);
	return exp;
}



//----------------------------------------------------------------



/*

IDEEventHandler::IDEEventHandler(void)
{
	next = 0;
}


IDEEventHandler::~IDEEventHandler(void)
{
}

IDEEventHandler* IDEEventHandler::initializeHandlerList(sPtr exp)
{
	IDEEventHandler *e = 0;
	e = new IDEKeyTypedHandler(e);
	e->setExpression(exp);
	e = new IDERuboutHandler(e);
	e->setExpression(exp);
	e = new IDEDeleteNodeHandler(e);
	e->setExpression(exp);
	e = new IDEPivotHandler(e);
	e->setExpression(exp);
	e = new IDEEvalHandler(e);
	e->setExpression(exp);
	e = new IDEMoveInHandler(e);
	e->setExpression(exp);
	e = new IDEEnlistHandler(e);
	e->setExpression(exp);
	e = new IDEMoveOutHandler(e);
	e->setExpression(exp);
	e = new IDEDisbandHandler(e);
	e->setExpression(exp);
	e = new IDEMovePreviousSiblingHandler(e);
	e->setExpression(exp);
	e = new IDEMoveNextSiblingHandler(e);
	e->setExpression(exp);
	e = new IDECreatePreviousSiblingHandler(e);
	e->setExpression(exp);
	e = new IDECreateNextSiblingHandler(e);
	e->setExpression(exp);
	return e;
}


sPtr IDEEventHandler::findSelectedChild(sPtr p)
{
	sPtr r;
	if (p->isPair()) {
		for ( ; !p->isType(XT_NULL) ; p = ((Pair*)p)->getCdr()) {
			if (((Pair*)p)->getCar()->getSelected()) {
				r = ((Pair*)p)->getCar();
			}
		}
	}
	return r;
}

void IDEEventHandler::swapSelected(sPtr a, sPtr b)
{
	if (a->getSelected() == 1) {
		if (b->getIsTop() == false) {
			b->setSelected(1);
			a->setSelected(0);
		}
	} else if (b->getSelected() == 1) {
		if (a->getIsTop() == false) {
			b->setSelected(0);
			a->setSelected(1);
		}
	}
}


//--------------------------------------------------------

bool IDECreateNextSiblingHandler::test(Event *e)
{
	int kv = e->keyvalue;
	// if the following aren't true, we don't even handle this type of event
	if (!e->ctrlDown) return false;
	if (!(kv == KEY_DOWNARROW || kv == KEY_RIGHTARROW)) return false;
	// if this isn't true, we can't call getCar to see if the child is selected
	// because we don't *have* a car.  Maybe only pairs get this handler?
	if (!exp->isPair()) return false;
	// if this isn't true, then this isn't the selected object.
	if (!((Pair*)exp)->getCar()->getSelected()) return false;
	// the top object (usually a list) can't have a sibling.
	if (exp->getIsTop()) return false;
	// down arrow creates a sibling for vertical lists,
	// right arrow creates a sibling for horizontal lists.
	if (kv == KEY_DOWNARROW && ((Pair*)exp)->getDirection() == VDIR) return true;
	if (kv == KEY_RIGHTARROW && ((Pair*)exp)->getDirection() == HDIR) return true;
	return false;
}

sPtr IDECreateNextSiblingHandler::handle(Event *e)
{
	((Pair*)exp)->setCdr(GSM.newPair(GSM.newExpression(), ((Pair*)exp)->getCdr()));
	((Pair*)((Pair*)exp)->getCdr())->setDirection(((Pair*)exp)->getDirection());
	swapSelected(((Pair*)exp)->getCar(), ((Pair*)((Pair*)exp)->getCdr())->getCar());
	exp->setDirtyness(exp->getDirtyness() | ((Pair*)exp)->getDirection());
	return exp;
}

//--------------------------------------------------------

bool IDECreatePreviousSiblingHandler::test(Event *e)
{
	int kv = e->keyvalue;
	// if the following aren't true, we don't even handle this type of event
	if (!e->ctrlDown) return false;
	if (!(kv == KEY_UPARROW || kv == KEY_LEFTARROW)) return false;
	// if this isn't true, we can't call getCar to see if the child is selected
	// because we don't *have* a car.  Maybe only pairs get this handler?
	if (!exp->isPair()) return false;
	// if this isn't true, then this isn't the selected object.
	if (!((Pair*)exp)->getCar()->getSelected()) return false;
	// the top object (usually a list) can't have a sibling.
	if (exp->getIsTop()) return false;
	// down arrow creates a sibling for vertical lists,
	// right arrow creates a sibling for horizontal lists.
	if (kv == KEY_UPARROW && ((Pair*)exp)->getDirection() == VDIR) return true;
	if (kv == KEY_LEFTARROW && ((Pair*)exp)->getDirection() == HDIR) return true;
	return false;
}

sPtr IDECreatePreviousSiblingHandler::handle(Event *e)
{
	sPtr n = GSM.newPair(GSM.newExpression(), exp);
	((Pair*)n)->setDirection(((Pair*)exp)->getDirection());
	swapSelected(((Pair*)n)->getCar(), ((Pair*)exp)->getCar());
	exp->setDirtyness(exp->getDirtyness() | ((Pair*)n)->getDirection());
	return n;
}

//--------------------------------------------------------

bool IDEMoveNextSiblingHandler::test(Event *e)
{
	int kv = e->keyvalue;

	if (e->ctrlDown) return false;
	if (!(kv == KEY_DOWNARROW || kv == KEY_RIGHTARROW)) return false;

	if (!exp->isPair()) return false;
	if (!((Pair*)exp)->getCar()->getSelected()) return false;
	if (!((Pair*)exp)->getCdr()->isPair()) return false;
	if (kv == KEY_DOWNARROW && ((Pair*)exp)->getDirection() == VDIR) return true;
	if (kv == KEY_RIGHTARROW && ((Pair*)exp)->getDirection() == HDIR) return true;
	return false;
}


sPtr IDEMoveNextSiblingHandler::handle(Event *e)
{
	swapSelected(((Pair*)exp)->getCar(), ((Pair*)((Pair*)exp)->getCdr())->getCar());
	//TRACE("dirtyness: %d\n", exp->getDirtyness());
	return exp;
}

//--------------------------------------------------------

bool IDEMovePreviousSiblingHandler::test(Event *e)
{
	int kv = e->keyvalue;
	if (e->ctrlDown) return false;
	if (!(kv == KEY_UPARROW || kv == KEY_LEFTARROW)) return false;
	if (!exp->isPair()) return false;
	if (!((Pair*)exp)->getCdr()->isPair()) return false;
	if (!((Pair*)((Pair*)exp)->getCdr())->getCar()->getSelected()) return false;
	if (kv == KEY_UPARROW && ((Pair*)exp)->getDirection() == VDIR) return true;
	if (kv == KEY_LEFTARROW && ((Pair*)exp)->getDirection() == HDIR) return true;
	return false;
}

sPtr IDEMovePreviousSiblingHandler::handle(Event *e)
{
	// move previous sibling
	swapSelected(((Pair*)((Pair*)exp)->getCdr())->getCar(), ((Pair*)exp)->getCar());
	return exp;
}

//--------------------------------------------------------

bool IDEDisbandHandler::test(Event *e)
{
	int kv = e->keyvalue;
	if (!e->ctrlDown) return false;
	if (!(kv == KEY_PGUP)) return false;
	if (!exp->isPair()) return false;
	if (!((Pair*)exp)->getCar()->isPair()) return false;
	if (!((Pair*)exp)->getCar()->getSelected()) return false;
	return true;
}
sPtr IDEDisbandHandler::handle(Event *e)
{
	// disband
	sPtr sel;
	sPtr restoflist;
	sel = ((Pair*)exp)->getCar();
	restoflist = ((Pair*)exp)->getCdr();
//	swapSelected(sel, exp);
	if (!((Pair*)sel)->getCdr()->isType(XT_NULL)) {
		((Pair*)exp)->setCdr(((Pair*)sel)->getCdr());
		((Pair*)sel->lastSibling())->setCdr(restoflist);
	}
	((Pair*)exp)->setCar(((Pair*)sel)->getCar());
	swapSelected(((Pair*)exp)->getCar(), sel);
	for (sPtr p = ((Pair*)exp)->getCdr() ; !p->isType(XT_NULL) ; p = ((Pair*)p)->getCdr()) {
		((Pair*)p)->setDirection(((Pair*)exp)->getDirection());
		// flailing in the dark...
		((Pair*)p)->setDirtyness(HDIR | VDIR | ZDIR);
	}
	((Pair*)exp)->getCar()->setDirtyness(exp->getDirtyness() | HDIR | VDIR | ZDIR);
	return exp;
}

//--------------------------------------------------------

bool IDEMoveOutHandler::test(Event *e)
{
	int kv = e->keyvalue;
	if (e->ctrlDown) return false;
	if (!(kv == KEY_PGUP)) return false;
	if (!exp->isPair()) return false;
	if (!findSelectedChild(exp)) return false;
	return true;
}
sPtr IDEMoveOutHandler::handle(Event *e)
{
	sPtr c = findSelectedChild(exp);
	swapSelected(exp, c);
	((Pair*)exp)->setCachedChild(c);
	return exp;
}

//--------------------------------------------------------

bool IDEEnlistHandler::test(Event *e)
{
	int kv = e->keyvalue;
	if (!e->ctrlDown) return false;
	if (!(kv == KEY_PGDOWN)) return false;
	if (!exp->getSelected()) return false;
	return true;
}
sPtr IDEEnlistHandler::handle(Event *e)
{
	// enlist
	sPtr n;
	n = GSM.newPair(exp, GSM.newNull());
	n->setDirtyness(n->getDirtyness() | HDIR | VDIR | ZDIR);
	//TRACE("%d", n->getDirtyness());
	return n;
}

//--------------------------------------------------------

bool IDEMoveInHandler::test(Event *e)
{
	int kv = e->keyvalue;
	if (e->ctrlDown) return false;
	if (!(kv == KEY_PGDOWN)) return false;
	if (!exp->isPair()) return false;
	if (!exp->getSelected()) return false;
	return true;
}
sPtr IDEMoveInHandler::handle(Event *e)
{
	sPtr cc = ((Pair*)exp)->getCachedChild();
	if (!!cc) {
		swapSelected(exp, cc);
	} else {
		swapSelected(((Pair*)exp)->getCar(), exp);
	}
	return exp;
}

//--------------------------------------------------------

bool IDEEvalHandler::test(Event *e)
{
	if (e->keyvalue != KEY_ENTER) return false;
	if (!exp->getSelected()) return false;
	return true;
}

sPtr IDEEvalHandler::handle(Event *e)
{
	sPtr n;
	exp->setSelected(0);
	Machine m;
	m.setup(exp);
	m.process();
	n = m.result();
//	n = exp->eval(exp->getEnvironment());
	n->setSelected(1);
	return n;
}

//--------------------------------------------------------

bool IDEPivotHandler::test(Event *e)
{
	if (e->keyvalue != KEY_SPACE) return false;
	if (!exp->getSelected()) return false;
	if (!exp->isPair()) return false;
	return true;
}

sPtr IDEPivotHandler::handle(Event *e)
{
	for (sPtr p = exp ; !p->isType(XT_NULL) ; p = ((Pair*)p)->getCdr()) {
		Direction current_dir, new_dir;
		current_dir = ((Pair*)p)->getDirection();
		switch(current_dir) {
		case HDIR:
			new_dir = VDIR;
			break;
		case VDIR:
			new_dir = ZDIR;
			break;
		case ZDIR:
			new_dir = HDIR;
			break;
		}
		((Pair*)p)->setDirection(new_dir);
		p->setDirtyness(p->getDirtyness() | HDIR | VDIR | ZDIR);
	}
	return exp;
}

//--------------------------------------------------------

bool IDEDeleteNodeHandler::test(Event *e)
{
	if (e->keyvalue != KEY_DELETE) return false;
	return ((exp->isPair()
			&& ((Pair*)exp)->getCar()->getSelected()
			) || (exp->isPair()
			&& !((Pair*)exp)->getCdr()->isType(XT_NULL)
			&& ((Pair*)((Pair*)exp)->getCdr())->getCar()->getSelected()
			));
}

sPtr IDEDeleteNodeHandler::handle(Event *e)
{
	if (exp->isPair()
		&& ((Pair*)exp)->getCar()->getSelected()) {
		if (((Pair*)exp)->getCdr()->isType(XT_NULL)) {
			((Pair*)exp)->getCdr()->setSelected(true);
		} else {
			((Pair*)((Pair*)exp)->getCdr())->getCar()->setSelected(true);
		}
		exp->setDirtyness(exp->getDirtyness() | ((Pair*)exp)->getDirection());
		return ((Pair*)exp)->getCdr();
	} else if (exp->isPair() 
		&& !((Pair*)exp)->getCdr()->isType(XT_NULL) 
		&& ((Pair*)((Pair*)exp)->getCdr())->getCar()->getSelected()) {
		((Pair*)exp)->getCar()->setSelected(true);
		((Pair*)exp)->setCdr(((Pair*)((Pair*)exp)->getCdr())->getCdr());
		exp->setDirtyness(exp->getDirtyness() | ((Pair*)exp)->getDirection());
		return exp;
	}
}

//--------------------------------------------------------

bool IDEKeyTypedHandler::test(Event *e)
{
	if (e->keyvalue >= 1000) return false; // special keys are >= 1000
	return (exp->isPair()
			&& ((Pair*)exp)->getCar()->getSelected()
			&& !((Pair*)exp)->getCar()->isPair());
}

sPtr IDEKeyTypedHandler::handle(Event *e)
{
	char buf[256];
	char *mt;
	mt = ((Pair*)exp)->getCar()->getMytext();
	assert(strlen(mt) + 2 < 256);
	if (!((Pair*)exp)->getCar()->isType(XT_UNKNOWN) && ((Pair*)exp)->getCar()->isType(XT_NULL)) {
		sprintf(buf, "%c", e->keyvalue);
	} else {
		sprintf(buf, "%s%c", mt, e->keyvalue);
	}
	((Pair*)exp)->setCar(GSM.newExpression(buf));
	((Pair*)exp)->getCar()->setSelected(true);
	exp->setDirtyness(exp->getDirtyness() | HDIR);
	return exp;
}

//--------------------------------------------------------

bool IDERuboutHandler::test(Event *e)
{
	if (e->keyvalue != KEY_BACKSPACE) return false;
	if (!exp->isPair()) return false;
	if (!((Pair*)exp)->getCar()->getSelected()) return false;
	if (((Pair*)exp)->getCar()->isPair()) return false;
	return true;
}

sPtr IDERuboutHandler::handle(Event *e)
{
	char buf[256];
	char *mt;
	mt = ((Pair*)exp)->getCar()->getMytext();
	assert(strlen(mt) + 2 < 256);
	sprintf(buf, "%s", mt, e->keyvalue);
	if (buf[0] != '\0') buf[strlen(buf) - 1] = '\0';
	((Pair*)exp)->setCar(GSM.newExpression(buf));
	((Pair*)exp)->getCar()->setSelected(true);
	exp->setDirtyness(exp->getDirtyness() | HDIR);
	return exp;
}

*/
