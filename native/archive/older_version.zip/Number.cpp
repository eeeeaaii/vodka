#include "Carin.h"
#include ".\number.h"
#using <mscorlib.dll>


Number::Number(void)
{
}

Number::~Number(void)
{
}
