#include "Carin.h"
#include "EventObserver.h"

EventObserver::EventObserver()
{
}

EventObserver::~EventObserver()
{
}

