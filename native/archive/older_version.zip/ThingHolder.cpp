#include "Carin.h"
#include "ThingHolder.h"

#include "Expression.h"
#include "Environment.h"
#include "StorageManager.h"
#include "Event.h"
#include "GraphicsContext.h"
#include "Pair.h"
#include "ForDebugging.h"
#include "EvalException.h"
#include "Machine.h"


ThingHolder::ThingHolder()
{
	GSM.initTopLevelEnvironment();
	sPtr newtop = GSM.newPair(GSM.newExpression(), GSM.newNull());
	setTop(newtop);
	topError = 0;
}

ThingHolder::~ThingHolder()
{
}

void ThingHolder::dumpTree()
{
	top->dumpTree(0);
}

unsigned int eventThreadStartup(void *argsvp)
{
	void **args;
	args = (void**) argsvp;
	ThingHolder *th = (ThingHolder*)args[0];
	Event *ev = (Event*)args[1];
	return th->handleEvent(ev);
	delete args;
	delete ev;
}

void ThingHolder::draw(GraphicsContext *gracon)
{
	Point p(0, 0);
	gracon->pushOrigin(p);
	dbg.trace("---------------------\n");
	dbg.trace("drawing\n");
	top->draw(gracon);
	top->dumpTree(0);
}

int ThingHolder::handleEvent(Event *e)
{
	dbg.trace("-------------------------\n");
	dbg.trace("handling event");
	dbg.trace(e->getID());
	dbg.trace("\n");
	GEH.notifyObservers(e);
	return 0;
}

void ThingHolder::init()
{
}

void ThingHolder::save(string filename)
{
	ofstream f(filename.c_str());
	string s = top->toString(top->isType(XT_PAIR));
	f << s;
	f.flush();
	f.close();
}

void ThingHolder::load(string filename)
{
	fstream f(filename.c_str());
	bool end_of_file = false;
	sPtr file = Expression::parseFromStream(f, end_of_file);
	top = GSM.newPair(file, GSM.newNull());
	file->setSelected(true);
	top->setIsTop(true);
}


void ThingHolder::setTop(sPtr newtop)
{
	top = newtop;
	top->setIsTop(true);
	if (top->isType(XT_PAIR)) {
		((Pair*)top)->getCar()->setSelected(true);
	}
}

sPtr ThingHolder::getTop()
{
	return top;
}

void ThingHolder::evaltop()
{
	try {
		Machine m;
		m.setup(top);
		m.process();
		top = m.result();
	} catch (EvalException *ee) {
		topError = ee;
	}
}

EvalException *ThingHolder::getError()
{
	EvalException *r;
	r = topError;
	topError = 0;
	return r;
}

void ThingHolder::setupIDEHandler(EventHandler *eh)
{
	idehanders.push_back(eh);
	GEH.subscribe(ET_KEYDOWN, eh);
}

void ThingHolder::setupHandlers()
{
	sPtr sel;
	sel = ((Pair*)top)->getCar();
	setupHandler(new IDECreateNextSiblingHandler(sel));
	// ...
	// ...
	// ...
}

sPtr ThingHolder::getSelected()
{
	return selected;
}

void ThingHolder::unsetSelected(sPtr oldsel)
{
}

void ThingHolder::swapSelected(sPtr oldsel, sPtr newsel)
{
	unsetSelected(oldsel);
	setSelected(newsel);
}


