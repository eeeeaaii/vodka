// This is the main project file for VC++ application project 
// generated using an Application Wizard.

#include "Carin.h"
#include "ThingHolder.h"
#include "Expression.h"
#include "Environment.h"
#include "EvalException.h"
#include <iostream>
#include <sstream>
#include <strstream>

#include <fstream>
#include "StorageManager.h"

#using <mscorlib.dll>

//using namespace carin;
using namespace std;
//using namespace System;
//extern StorageManager GSM;

const char* usage = "unittest [<input-file>] [<output-file>]\n";

/*
void doExpression(const char* expression)
{
	string z(expression);
	stringstream s(z);
	sPtr top = Expression::parseFromStream(s);
	Environment *e = top->getEnvironment();
	top = top->eval(e);
	cout << z << " -> " << top->toString(true) << "\n";
}
*/

void parseExpressions(istream& s);


void parseExpressions(istream& s)
{
	ThingHolder th;
	sPtr exp;
	bool end_of_file = false;
	while(!!(exp = Expression::parseFromStream(s, end_of_file)) && !end_of_file) {
		th.setTop(exp);
		th.evaltop();
		EvalException *ee;
		if (ee = th.getError()) {
			cout << ee->message << "\n";
			delete ee;
		} else {
			exp = th.getTop();
			cout << exp->toString() << "\n";
		}
	}
}

int _tmain(int argc, TCHAR* argv[])
{
	if (argc > 1) {
        char *fname = argv[1];
		ifstream s;
		s.open(fname);
		if (s.is_open()) {
			cout << usage;
			return 1;
		}
		parseExpressions(s);
	} else {
		parseExpressions(cin);
	}
	//parseExpressions(s);
//	istringstream ss("(+ 3 4) \n (- 5 2)");
	return 0;
}